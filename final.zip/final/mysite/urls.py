from django.urls import path
from . import views

urlpatterns = [
    path('mysite/', views.mysite, name='mysite'),
]